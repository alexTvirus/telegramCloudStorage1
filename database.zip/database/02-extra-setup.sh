#!/usr/bin/env bash

set -euo pipefail

echo "[02-extra-setup] running extra init commands..."

# Sử dụng mongosh để tạo user chỉ đọc (read-only) cho database hiện tại
mongosh --username "$MONGO_INITDB_ROOT_USERNAME" \
        --password "$MONGO_INITDB_ROOT_PASSWORD" \
        --authenticationDatabase "admin" \
        "$MONGO_INITDB_DATABASE" <<EOF
    
    // Kiểm tra nếu user 'it_kb_readonly' chưa tồn tại thì tạo mới
    var userExists = db.getUser("it_kb_readonly");
    if (!userExists) {
        db.createUser({
            user: "it_kb_readonly",
            pwd: "change_me",
            roles: [
                { role: "read", db: "$MONGO_INITDB_DATABASE" } // Quyền chỉ đọc trên database này
            ]
        });
        print("User 'it_kb_readonly' created successfully.");
    } else {
        print("User 'it_kb_readonly' already exists.");
    }
EOF

# Tạo thư mục dữ liệu phụ (nếu ứng dụng của bạn cần lưu file ngoài db)
mkdir -p /data/db/it_kb_extra

# Thay thế lệnh kiểm tra extension của Postgres bằng lệnh kiểm tra trạng thái Build của MongoDB
mongosh --username "$MONGO_INITDB_ROOT_USERNAME" \
        --password "$MONGO_INITDB_ROOT_PASSWORD" \
        --authenticationDatabase "admin" \
        --eval "db.serverBuildInfo()"

echo "[02-extra-setup] done."
