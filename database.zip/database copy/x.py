import collections
import heapq
import random


def shuffle_clients(sub_arrays):
    # Bước 1: Trộn ngẫu nhiên nội bộ từng mảng con trước để tăng tính ngẫu nhiên
    pool = []
    for group_name, elements in sub_arrays.items():
        shuffled_elements = list(elements)
        random.shuffle(shuffled_elements)
        pool.append((group_name, shuffled_elements))

    # Đếm số lượng và lưu trữ dữ liệu
    counts = collections.defaultdict(int)
    group_data = collections.defaultdict(list)

    for group_name, elements in pool:
        counts[group_name] = len(elements)
        group_data[group_name] = elements

    # Bước 2: Đưa vào Max-Heap (sắp xếp giảm dần theo số lượng phần tử)
    max_heap = [[-count, group] for group, count in counts.items() if count > 0]
    heapq.heapify(max_heap)

    clients = []
    prev_group = None
    prev_count = 0

    # Bước 3: Rút từ Heap để xếp xen kẽ tối đa có thể
    while max_heap:
        count, group = heapq.heappop(max_heap)

        # Thêm phần tử vào danh sách clients
        item = group_data[group].pop(0)
        clients.append(item)

        count += 1  # Giảm số lượng phần tử thực tế (vì dùng số âm)

        # Trả lại nhóm bị giữ ở lượt trước vào Heap (nếu nó còn phần tử)
        if prev_group and prev_count < 0:
            heapq.heappush(max_heap, [prev_count, prev_group])

        # Giữ nhóm hiện tại lại, không cho bốc ở lượt kế tiếp
        prev_group = group
        prev_count = count

    # CHỈNH SỬA TẠI ĐÂY: Nếu không thể xen kẽ được nữa, chấp nhận dồn các phần tử còn lại vào cuối
    if prev_group and prev_count < 0:
        # Lấy hết tất cả phần tử còn lại của nhóm này xếp liền kề ở cuối
        remaining_elements = group_data[prev_group]
        clients.extend(remaining_elements)

    return clients


# --- CHẠY THỬ NGHIỆM ---
# Giả sử bạn có các mảng con A, B, C ban đầu
A = ["A1", "A2", "A3","a12","a4384","a32","a482","a4838","a4382"]
B = ["B1", "B2","b237","b4388"]
C = ["C1", "C2", "C3"]

sub_arrays = {"A": A, "B": B}

try:
    clients = shuffle_clients(sub_arrays)
    print("Mảng clients sau khi trộn hợp lệ:")
    print(clients)
except ValueError as e:
    print(e)
